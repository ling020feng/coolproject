package com.xpf.android_gif;

import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

import pl.droidsonroids.gif.GifImageView;

/**
 * @author: lgw
 * @date: 19-12-17 下午8:18
 * @desc:
 */
public class DoorDialog extends Dialog implements View.OnClickListener {
    TextView title;
    TextView text;
    TextView cancel;
    TextView ok;
    View line;
    GifImageView doorGif;
    GifImageView doorGif2;
    TextView tvTitleBottomMsg;
    TextView gifNumble;
    TextView ThridVoiceUrl;
    void onClickOk() {
        if (onDialogClickListener != null) {
            onDialogClickListener.onDialogClick(this, ok, DoorDialog.BUTTON.OK);
        }
    }

    void onClickCancel() {
        if (onDialogClickListener != null) {
            onDialogClickListener.onDialogClick(this, cancel, DoorDialog.BUTTON.CANCEL);
        }
    }
    void onClickGif(){
        if (onDialogClickListener != null) {
            onDialogClickListener.onDialogClick(this, cancel, BUTTON.GIF1);
            if(doorGif.getVisibility() == View.VISIBLE){
                doorGif.setVisibility(View.GONE);
                doorGif2.setVisibility(View.VISIBLE);
                ThridVoiceUrl.setVisibility(View.VISIBLE);
                tvTitleBottomMsg.setText("You can find this instruction in \" Profile - Third Party Voice Access \"");
                gifNumble.setText("2/2");
            }
        }
    }
    void onClickGif2(){
        if (onDialogClickListener != null) {
            onDialogClickListener.onDialogClick(this, cancel, BUTTON.GIF2);
            if(doorGif2.getVisibility() == View.VISIBLE){
                doorGif2.setVisibility(View.GONE);
                doorGif.setVisibility(View.VISIBLE);
                ThridVoiceUrl.setVisibility(View.GONE);
                tvTitleBottomMsg.setText("Please follow the instruction to complete the installation and pair with your garage door opener for the first time");
                gifNumble.setText("1/2");
            }
        }
    }
    private DoorDialog.OnDialogClickListener onDialogClickListener;

    public DoorDialog(Context context) {
        super(context, R.style.common_dialog_style);
        View view = getLayoutInflater().inflate(R.layout.door_dialog_layout, null);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        setContentView(view, params);

        initView(view);
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.width = WindowManager.LayoutParams.MATCH_PARENT;
        attributes.gravity = Gravity.BOTTOM;
        getWindow().setAttributes(attributes);
    }

    private void initView(View view) {
        title = (TextView) view.findViewById(R.id.tv_title_dialog);
        text = (TextView) view.findViewById(R.id.tv_text_dialog);
        cancel = (TextView) findViewById(R.id.danale_info_dialog_cancel_btn);
        ok = (TextView) findViewById(R.id.danale_info_dialog_ok_btn);
        tvTitleBottomMsg = findViewById(R.id.tv_title_dialog_bottom_msg);
        gifNumble = findViewById(R.id.gif_numble);
        ThridVoiceUrl = findViewById(R.id.thrid_voice_url);


        line =(View)findViewById(R.id.id_line);
        doorGif = findViewById(R.id.door_gif);
        doorGif2 = findViewById(R.id.door_gif2);
        doorGif.setOnClickListener(this);
        doorGif2.setOnClickListener(this);
        cancel.setOnClickListener(this);
        ok.setOnClickListener(this);


    }

    public DoorDialog setGravity(int gravity){
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        WindowManager.LayoutParams attributes = getWindow().getAttributes();
        attributes.width = WindowManager.LayoutParams.MATCH_PARENT;
        attributes.gravity = gravity;
        getWindow().setAttributes(attributes);
        return this;
    }

    public DoorDialog hasTitleView(boolean has) {
        title.setVisibility(has ? View.VISIBLE : View.GONE);
        return this;
    }

    public DoorDialog hasTextView(boolean has){
        text.setVisibility(has ? View.VISIBLE : View.GONE);
        return this;
    }

    public DoorDialog setTextInfo(String res){
        text.setText(res);
        return this;
    }

    public DoorDialog hasButtonCancel(boolean has) {
        cancel.setVisibility(has ? View.VISIBLE : View.GONE);
        line.setVisibility(has ? View.VISIBLE : View.GONE);
        return this;
    }

    public DoorDialog setInfoTitle(String title) {
        this.title.setText(title);
        return this;
    }

    public DoorDialog setInfoTitle(int res) {
        this.title.setText(res);
        return this;
    }

    public DoorDialog setcancelButtonText(int res) {
        this.cancel.setText(res);
        return this;
    }

    public DoorDialog setokButtonText(int res) {
        this.ok.setText(res);
        return this;
    }


    public DoorDialog onDialogClick(DoorDialog.OnDialogClickListener listener) {
        this.onDialogClickListener = listener;
        return this;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.danale_info_dialog_ok_btn) {
            onClickOk();
        } else if (v.getId() == R.id.danale_info_dialog_cancel_btn) {
            onClickCancel();
        }else if (v.getId() == R.id.door_gif){
            onClickGif();
        }else if (v.getId() == R.id.door_gif2){
            onClickGif2();
        }
    }

    public static DoorDialog create(Context context){
        return new DoorDialog(context);
    }

    public interface OnDialogClickListener {
        void onDialogClick(DoorDialog dialog, View btn, DoorDialog.BUTTON which);
    }

    public enum BUTTON {
        OK, CANCEL,GIF1,GIF2
    }
}
