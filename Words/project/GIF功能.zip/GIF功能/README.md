# Android-GIF-Loader

Android-GIF-Loader

- 支持两种方式加载 GIF;
- 使用 Glide 4.7.1;
- 支持设置加载一次 GIF；
- ...
